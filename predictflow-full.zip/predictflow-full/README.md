# PredictFlow — Plataforma de Previsões ao Vivo

## Stack
- **Backend:** Node.js + Express + MongoDB
- **Frontend:** Next.js 14 + TailwindCSS + Zustand
- **Auth:** JWT (access + refresh tokens)
- **Deploy:** Vercel (frontend) + Railway/Render (backend)

---

## Estrutura do Projeto

```
predictflow-full/
├── backend/
│   └── src/
│       ├── config/         # Database connection
│       ├── middleware/      # Auth, validation, error handler
│       ├── models/          # User, Transaction, Prediction, Bet
│       ├── routes/          # auth, users, wallet, predictions, admin
│       ├── services/        # authService, walletService, predictionService, paymentService
│       └── utils/           # logger, seed script
└── frontend/
    └── src/
        ├── app/             # Next.js App Router pages
        │   ├── auth/        # Login, Register
        │   ├── dashboard/   # Página principal
        │   ├── wallet/      # Carteira
        │   ├── profile/     # Perfil
        │   └── admin/       # Painel admin
        ├── lib/             # API client (axios)
        └── store/           # Zustand auth store
```

---

## Setup — Backend

### 1. Instalar dependências
```bash
cd backend
npm install
```

### 2. Configurar variáveis de ambiente
```bash
cp .env.example .env
# Edite o .env com suas credenciais
```

### 3. Criar banco MongoDB
- Acesse https://cloud.mongodb.com
- Crie um cluster gratuito
- Copie a connection string para MONGODB_URI no .env

### 4. Rodar o seed (dados iniciais)
```bash
npm run seed
```

### 5. Iniciar o servidor
```bash
npm run dev    # desenvolvimento
npm start      # produção
```

API disponível em: http://localhost:5000

---

## Setup — Frontend

### 1. Instalar dependências
```bash
cd frontend
npm install
```

### 2. Configurar variáveis
```bash
cp .env.local.example .env.local
# NEXT_PUBLIC_API_URL=http://localhost:5000/api
```

### 3. Iniciar
```bash
npm run dev
```

Frontend disponível em: http://localhost:3000

---

## API Endpoints

### Auth
| Método | Rota | Descrição |
|--------|------|-----------|
| POST | /api/auth/register | Criar conta |
| POST | /api/auth/login | Login |
| POST | /api/auth/refresh | Renovar token |
| POST | /api/auth/logout | Logout |
| GET  | /api/auth/me | Dados do usuário |

### Wallet
| Método | Rota | Descrição |
|--------|------|-----------|
| GET | /api/wallet/balance | Saldo atual |
| GET | /api/wallet/transactions | Histórico |
| POST | /api/wallet/deposit | Depositar |
| POST | /api/wallet/withdraw | Solicitar saque |
| POST | /api/wallet/daily-bonus | Bônus diário |

### Predictions
| Método | Rota | Descrição |
|--------|------|-----------|
| GET | /api/predictions | Listar ativas |
| GET | /api/predictions/:id | Detalhes |
| POST | /api/predictions/:id/bet | Fazer aposta |
| GET | /api/predictions/user/bets | Minhas apostas |

### Admin (requer role: admin)
| Método | Rota | Descrição |
|--------|------|-----------|
| GET | /api/admin/dashboard | Estatísticas |
| GET | /api/admin/users | Listar usuários |
| PATCH | /api/admin/users/:id/ban | Banir usuário |
| POST | /api/admin/predictions | Criar previsão |
| POST | /api/admin/predictions/:id/resolve | Resolver |
| GET | /api/admin/withdrawals | Saques pendentes |
| POST | /api/admin/withdrawals/:id/approve | Aprovar saque |
| POST | /api/admin/withdrawals/:id/reject | Rejeitar saque |

---

## Deploy

### Backend — Railway
1. Crie conta em railway.app
2. New Project → Deploy from GitHub
3. Adicione as variáveis de ambiente
4. Deploy automático

### Frontend — Vercel
```bash
cd frontend
npx vercel --prod
# Adicione NEXT_PUBLIC_API_URL com a URL do backend no Railway
```

---

## Integrar Pagamentos

O arquivo `backend/src/services/paymentService.js` tem a abstração pronta.

### Mercado Pago
```bash
npm install mercadopago
```
1. Adicione `MERCADOPAGO_ACCESS_TOKEN` no .env
2. Implemente os métodos em `providers.mercadopago`
3. Configure webhook: `POST /api/webhooks/payment`

### Stripe
```bash
npm install stripe
```
1. Adicione `STRIPE_SECRET_KEY` no .env
2. Implemente os métodos em `providers.stripe`

---

## Usuários de Teste (após seed)

| Email | Senha | Role |
|-------|-------|------|
| admin@predictflow.com | Admin@123456 | admin |
| joao@test.com | Test@123456 | user |
| maria@test.com | Test@123456 | user |

---

## Segurança Implementada
- ✅ JWT access (15min) + refresh (7 dias)
- ✅ Bcrypt para senhas
- ✅ Rate limiting (100 req/15min geral, 10 para auth)
- ✅ Validação de inputs com Joi
- ✅ Transações atômicas MongoDB (prevent double spending)
- ✅ Middleware de autenticação em todas rotas protegidas
- ✅ Role-based access control (admin/user)
- ✅ Helmet para headers de segurança
- ✅ CORS configurado
