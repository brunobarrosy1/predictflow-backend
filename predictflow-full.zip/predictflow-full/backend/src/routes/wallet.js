const express = require('express');
const walletService = require('../services/walletService');
const paymentService = require('../services/paymentService');
const { authenticate } = require('../middleware/auth');
const { validate, schemas } = require('../middleware/validate');
const { asyncHandler } = require('../middleware/errorHandler');

const router = express.Router();

router.use(authenticate);

router.get('/balance', asyncHandler(async (req, res) => {
  res.json({ balance: req.user.balance });
}));

router.get('/transactions', asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, type } = req.query;
  const result = await walletService.getTransactions(req.user._id, +page, +limit, type);
  res.json(result);
}));

router.post('/deposit', validate(schemas.deposit), asyncHandler(async (req, res) => {
  const { amount } = req.body;
  // Create payment intent
  const payment = await paymentService.createDeposit({
    userId: req.user._id,
    amount,
    email: req.user.email,
  });

  // For mock provider — credit immediately
  if (paymentService.getActiveProvider() === 'mock') {
    const result = await walletService.deposit(req.user._id, amount);
    return res.json({ ...result, payment });
  }

  res.json({ payment, message: 'Aguarde confirmação do pagamento' });
}));

router.post('/withdraw', validate(schemas.withdraw), asyncHandler(async (req, res) => {
  const { amount, pixKey } = req.body;
  const result = await walletService.requestWithdrawal(req.user._id, amount, pixKey);
  res.json({ ...result, message: 'Saque solicitado. Aguarde aprovação em até 24h.' });
}));

router.post('/daily-bonus', asyncHandler(async (req, res) => {
  const result = await walletService.claimDailyBonus(req.user._id);
  res.json(result);
}));

module.exports = router;
