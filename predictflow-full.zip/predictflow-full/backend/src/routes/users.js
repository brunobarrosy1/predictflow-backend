const express = require('express');
const User = require('../models/User');
const Bet = require('../models/Bet');
const { authenticate } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');

const router = express.Router();

router.use(authenticate);

router.get('/profile', asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);
  const betStats = await Bet.aggregate([
    { $match: { userId: req.user._id } },
    { $group: {
      _id: '$status',
      count: { $sum: 1 },
      total: { $sum: '$amount' },
    }}
  ]);
  res.json({ user: user.toSafeObject(), betStats });
}));

router.get('/leaderboard', asyncHandler(async (req, res) => {
  const leaders = await User.find({ isActive: true, isBanned: false })
    .select('name xp level totalWon balance')
    .sort({ totalWon: -1 })
    .limit(10);
  res.json({ leaders });
}));

router.patch('/profile', asyncHandler(async (req, res) => {
  const { name } = req.body;
  if (name) {
    await User.findByIdAndUpdate(req.user._id, { name });
  }
  res.json({ message: 'Perfil atualizado' });
}));

module.exports = router;
