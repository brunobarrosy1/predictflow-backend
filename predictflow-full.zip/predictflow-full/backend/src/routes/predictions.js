const express = require('express');
const predictionService = require('../services/predictionService');
const { authenticate, optionalAuth } = require('../middleware/auth');
const { validate, schemas } = require('../middleware/validate');
const { asyncHandler } = require('../middleware/errorHandler');

const router = express.Router();

router.get('/', optionalAuth, asyncHandler(async (req, res) => {
  const { category } = req.query;
  const predictions = await predictionService.getActive(category);
  res.json({ predictions });
}));

router.get('/:id', asyncHandler(async (req, res) => {
  const prediction = await predictionService.getById(req.params.id);
  res.json({ prediction });
}));

router.post('/:id/bet', authenticate, validate(schemas.placeBet), asyncHandler(async (req, res) => {
  const { optionId, amount } = req.body;
  const result = await predictionService.placeBet(
    req.user._id, req.params.id, optionId, amount
  );
  res.status(201).json(result);
}));

router.get('/user/bets', authenticate, asyncHandler(async (req, res) => {
  const { page = 1, limit = 20 } = req.query;
  const result = await predictionService.getUserBets(req.user._id, +page, +limit);
  res.json(result);
}));

module.exports = router;
