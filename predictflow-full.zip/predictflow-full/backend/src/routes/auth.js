// ── AUTH ROUTES (/api/auth) ──────────────────────────────────
const express = require('express');
const { authService } = require('../services/authService');
const { validate, schemas } = require('../middleware/validate');
const { authenticate } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');

const authRouter = express.Router();

authRouter.post('/register', validate(schemas.register), asyncHandler(async (req, res) => {
  const result = await authService.register(req.body);
  res.status(201).json(result);
}));

authRouter.post('/login', validate(schemas.login), asyncHandler(async (req, res) => {
  const result = await authService.login(req.body);
  res.json(result);
}));

authRouter.post('/refresh', asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) return res.status(400).json({ error: 'Refresh token obrigatório' });
  const tokens = await authService.refreshToken(refreshToken);
  res.json(tokens);
}));

authRouter.post('/logout', authenticate, asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;
  await authService.logout(req.user._id, refreshToken);
  res.json({ message: 'Logout realizado' });
}));

authRouter.get('/me', authenticate, asyncHandler(async (req, res) => {
  res.json({ user: req.user.toSafeObject() });
}));

module.exports = authRouter;
