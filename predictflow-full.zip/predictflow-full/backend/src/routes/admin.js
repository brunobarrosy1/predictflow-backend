const express = require('express');
const User = require('../models/User');
const Bet = require('../models/Bet');
const Transaction = require('../models/Transaction');
const Prediction = require('../models/Prediction');
const predictionService = require('../services/predictionService');
const { authenticate, requireAdmin } = require('../middleware/auth');
const { validate, schemas } = require('../middleware/validate');
const { asyncHandler } = require('../middleware/errorHandler');

const router = express.Router();

router.use(authenticate, requireAdmin);

// ── DASHBOARD ──
router.get('/dashboard', asyncHandler(async (req, res) => {
  const [
    totalUsers, activeToday, totalBets,
    totalVolume, pendingWithdrawals, openPredictions
  ] = await Promise.all([
    User.countDocuments({ role: 'user' }),
    User.countDocuments({ lastLoginDate: { $gte: new Date(Date.now() - 86400000) } }),
    Bet.countDocuments(),
    Transaction.aggregate([
      { $match: { type: 'deposit', status: 'completed' } },
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ]),
    Transaction.countDocuments({ type: 'withdrawal', status: 'pending' }),
    Prediction.countDocuments({ status: 'open' }),
  ]);

  res.json({
    users: { total: totalUsers, activeToday },
    bets: { total: totalBets },
    volume: { total: totalVolume[0]?.total || 0 },
    pendingWithdrawals,
    openPredictions,
  });
}));

// ── USERS ──
router.get('/users', asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, search } = req.query;
  const filter = {};
  if (search) filter.$or = [
    { email: new RegExp(search, 'i') },
    { name: new RegExp(search, 'i') },
  ];
  const [users, total] = await Promise.all([
    User.find(filter).sort({ createdAt: -1 }).skip((page-1)*limit).limit(+limit),
    User.countDocuments(filter)
  ]);
  res.json({ users: users.map(u => u.toSafeObject()), total, pages: Math.ceil(total/limit) });
}));

router.patch('/users/:id/balance', asyncHandler(async (req, res) => {
  const { amount, reason } = req.body;
  if (!amount || !reason) return res.status(400).json({ error: 'amount e reason obrigatórios' });
  const user = await User.findById(req.params.id);
  if (!user) return res.status(404).json({ error: 'Usuário não encontrado' });
  const before = user.balance;
  user.balance = Math.max(0, parseFloat((user.balance + amount).toFixed(2)));
  await user.save();
  await Transaction.create({
    userId: user._id, type: 'bonus', amount,
    balanceBefore: before, balanceAfter: user.balance,
    description: `Ajuste manual: ${reason}`, status: 'completed',
  });
  res.json({ balance: user.balance, message: 'Saldo ajustado' });
}));

router.patch('/users/:id/ban', asyncHandler(async (req, res) => {
  const { reason } = req.body;
  await User.findByIdAndUpdate(req.params.id, {
    isBanned: true, banReason: reason || 'Violação dos termos'
  });
  res.json({ message: 'Usuário banido' });
}));

router.patch('/users/:id/unban', asyncHandler(async (req, res) => {
  await User.findByIdAndUpdate(req.params.id, { isBanned: false, banReason: null });
  res.json({ message: 'Usuário desbanido' });
}));

// ── PREDICTIONS ──
router.get('/predictions', asyncHandler(async (req, res) => {
  const { status } = req.query;
  const filter = status ? { status } : {};
  const predictions = await Prediction.find(filter)
    .populate('createdBy', 'name email')
    .sort({ createdAt: -1 }).limit(50);
  res.json({ predictions });
}));

router.post('/predictions', validate(schemas.createPrediction), asyncHandler(async (req, res) => {
  const prediction = await predictionService.create(req.user._id, req.body);
  res.status(201).json({ prediction });
}));

router.post('/predictions/:id/resolve', asyncHandler(async (req, res) => {
  const { winnerOptionId } = req.body;
  if (!winnerOptionId) return res.status(400).json({ error: 'winnerOptionId obrigatório' });
  const result = await predictionService.resolve(req.params.id, winnerOptionId, req.user._id);
  res.json(result);
}));

router.patch('/predictions/:id/status', asyncHandler(async (req, res) => {
  const { status } = req.body;
  if (!['open','locked','cancelled'].includes(status)) {
    return res.status(400).json({ error: 'Status inválido' });
  }
  const prediction = await Prediction.findByIdAndUpdate(
    req.params.id, { status }, { new: true }
  );
  if (!prediction) return res.status(404).json({ error: 'Previsão não encontrada' });

  // Refund if cancelled
  if (status === 'cancelled') {
    const bets = await Bet.find({ predictionId: req.params.id, status: 'pending' });
    for (const bet of bets) {
      const user = await User.findById(bet.userId);
      if (user) {
        const before = user.balance;
        user.balance = parseFloat((user.balance + bet.amount).toFixed(2));
        await user.save();
        await Transaction.create({
          userId: bet.userId, type: 'refund', amount: bet.amount,
          balanceBefore: before, balanceAfter: user.balance,
          description: `Reembolso: ${prediction.title}`,
          referenceId: bet._id.toString(), status: 'completed',
        });
        bet.status = 'refunded';
        await bet.save();
      }
    }
  }
  res.json({ prediction, message: `Status atualizado para ${status}` });
}));

// ── WITHDRAWALS ──
router.get('/withdrawals', asyncHandler(async (req, res) => {
  const withdrawals = await Transaction.find({ type: 'withdrawal', status: 'pending' })
    .populate('userId', 'name email')
    .sort({ createdAt: 1 });
  res.json({ withdrawals });
}));

router.post('/withdrawals/:id/approve', asyncHandler(async (req, res) => {
  const tx = await Transaction.findById(req.params.id);
  if (!tx || tx.type !== 'withdrawal' || tx.status !== 'pending') {
    return res.status(400).json({ error: 'Saque não encontrado ou já processado' });
  }
  tx.status = 'completed';
  tx.metadata = { ...tx.metadata, approvedBy: req.user._id, approvedAt: new Date() };
  await tx.save();
  await User.findByIdAndUpdate(tx.userId, { $inc: { totalWithdrawn: tx.amount } });
  res.json({ message: 'Saque aprovado' });
}));

router.post('/withdrawals/:id/reject', asyncHandler(async (req, res) => {
  const tx = await Transaction.findById(req.params.id);
  if (!tx || tx.type !== 'withdrawal' || tx.status !== 'pending') {
    return res.status(400).json({ error: 'Saque não encontrado' });
  }
  // Refund user
  const user = await User.findById(tx.userId);
  if (user) {
    const before = user.balance;
    user.balance = parseFloat((user.balance + tx.amount).toFixed(2));
    await user.save();
    await Transaction.create({
      userId: tx.userId, type: 'refund', amount: tx.amount,
      balanceBefore: before, balanceAfter: user.balance,
      description: 'Reembolso: saque rejeitado', status: 'completed',
    });
  }
  tx.status = 'cancelled';
  tx.metadata = { ...tx.metadata, rejectedBy: req.user._id, rejectedAt: new Date() };
  await tx.save();
  res.json({ message: 'Saque rejeitado e valor estornado' });
}));

module.exports = router;
