const Joi = require('joi');

const validate = (schema) => (req, res, next) => {
  const { error } = schema.validate(req.body, { abortEarly: false });
  if (error) {
    const message = error.details.map(d => d.message).join('; ');
    return res.status(400).json({ error: message });
  }
  next();
};

const schemas = {
  register: Joi.object({
    email: Joi.string().email().required().messages({ 'string.email': 'Email inválido' }),
    password: Joi.string().min(6).required().messages({ 'string.min': 'Senha mínima: 6 caracteres' }),
    name: Joi.string().min(2).max(50).required(),
    referralCode: Joi.string().optional(),
  }),

  login: Joi.object({
    email: Joi.string().email().required(),
    password: Joi.string().required(),
  }),

  placeBet: Joi.object({
    predictionId: Joi.string().required(),
    optionId: Joi.string().required(),
    amount: Joi.number().min(1).max(10000).required(),
  }),

  deposit: Joi.object({
    amount: Joi.number().min(10).max(50000).required(),
  }),

  withdraw: Joi.object({
    amount: Joi.number().min(20).required(),
    pixKey: Joi.string().min(5).required(),
  }),

  createPrediction: Joi.object({
    title: Joi.string().min(5).max(200).required(),
    category: Joi.string().valid('transito','pedestre','animais','futebol','bitcoin','custom').required(),
    options: Joi.array().items(Joi.object({
      id: Joi.string().optional(),
      label: Joi.string().required(),
    })).min(2).max(8).required(),
    duration: Joi.number().min(10).max(3600).required(),
    videoUrl: Joi.string().uri().optional().allow(''),
  }),

  resolveMarket: Joi.object({
    winnerOptionId: Joi.string().required(),
  }),
};

module.exports = { validate, schemas };
