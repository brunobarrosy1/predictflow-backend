const logger = require('../utils/logger');

const errorHandler = (err, req, res, next) => {
  const status = err.status || err.statusCode || 500;
  const message = err.message || 'Erro interno do servidor';

  if (status >= 500) {
    logger.error(`${req.method} ${req.path} — ${status}: ${message}`, {
      stack: err.stack,
      body: req.body,
      user: req.user?._id,
    });
  } else {
    logger.warn(`${req.method} ${req.path} — ${status}: ${message}`);
  }

  res.status(status).json({
    error: message,
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
};

const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

module.exports = errorHandler;
module.exports.asyncHandler = asyncHandler;
