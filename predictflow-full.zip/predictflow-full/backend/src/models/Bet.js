const mongoose = require('mongoose');

const betSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  predictionId: { type: mongoose.Schema.Types.ObjectId, ref: 'Prediction', required: true },
  optionId: { type: String, required: true },
  optionLabel: { type: String },
  amount: { type: Number, required: true, min: 1 },
  oddsAtBet: { type: Number },
  potentialPayout: { type: Number },
  actualPayout: { type: Number, default: 0 },
  status: {
    type: String,
    enum: ['pending', 'won', 'lost', 'refunded'],
    default: 'pending'
  },
}, { timestamps: true });

betSchema.index({ userId: 1, createdAt: -1 });
betSchema.index({ predictionId: 1, status: 1 });
// Prevent double bet on same prediction
betSchema.index({ userId: 1, predictionId: 1 }, { unique: true });

module.exports = mongoose.model('Bet', betSchema);
