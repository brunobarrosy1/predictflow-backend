const mongoose = require('mongoose');

const predictionSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  category: {
    type: String,
    enum: ['transito', 'pedestre', 'animais', 'futebol', 'bitcoin', 'custom'],
    required: true
  },
  options: [{
    id: String,
    label: String,
    pool: { type: Number, default: 0 },
    betCount: { type: Number, default: 0 },
  }],
  duration: { type: Number, required: true }, // seconds
  status: {
    type: String,
    enum: ['open', 'locked', 'resolved', 'cancelled'],
    default: 'open'
  },
  winnerOptionId: { type: String, default: null },
  houseEdge: { type: Number, default: 0.05 },
  totalPool: { type: Number, default: 0 },
  totalBets: { type: Number, default: 0 },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  resolvedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  opensAt: { type: Date, default: Date.now },
  closesAt: { type: Date },
  resolvedAt: { type: Date },
  videoUrl: { type: String },
}, { timestamps: true });

predictionSchema.index({ status: 1, category: 1 });
predictionSchema.index({ createdAt: -1 });

module.exports = mongoose.model('Prediction', predictionSchema);
