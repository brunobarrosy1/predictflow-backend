require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const Prediction = require('../models/Prediction');
const Transaction = require('../models/Transaction');

const seed = async () => {
  await mongoose.connect(process.env.MONGODB_URI);
  console.log('Connected to MongoDB');

  // Clean existing data
  await User.deleteMany({});
  await Prediction.deleteMany({});
  await Transaction.deleteMany({});
  console.log('Cleaned existing data');

  // Create admin
  const admin = new User({
    email: process.env.ADMIN_EMAIL || 'admin@predictflow.com',
    password: process.env.ADMIN_PASSWORD || 'Admin@123456',
    name: 'Admin',
    role: 'admin',
    balance: 0,
  });
  await admin.save();
  console.log('Admin created:', admin.email);

  // Create test users
  const users = [];
  const testData = [
    { name: 'João Silva',    email: 'joao@test.com',    balance: 250 },
    { name: 'Maria Santos',  email: 'maria@test.com',   balance: 480 },
    { name: 'Carlos Oliveira', email: 'carlos@test.com', balance: 120 },
    { name: 'Ana Costa',     email: 'ana@test.com',     balance: 780 },
    { name: 'Pedro Lima',    email: 'pedro@test.com',   balance: 340 },
  ];

  for (const data of testData) {
    const user = new User({ ...data, password: 'Test@123456' });
    await user.save();
    await Transaction.create({
      userId: user._id, type: 'bonus', amount: data.balance,
      balanceBefore: 0, balanceAfter: data.balance,
      description: 'Saldo inicial (seed)', status: 'completed',
    });
    users.push(user);
  }
  console.log(`Created ${users.length} test users`);

  // Create sample predictions
  const predictions = [
    {
      title: 'Próximo veículo será:',
      category: 'transito',
      options: [
        { id: 'carro', label: 'Carro', pool: 120, betCount: 8 },
        { id: 'moto', label: 'Moto', pool: 80, betCount: 5 },
        { id: 'caminhao', label: 'Caminhão', pool: 40, betCount: 3 },
      ],
      duration: 60, totalPool: 240, totalBets: 16,
      status: 'open', createdBy: admin._id,
    },
    {
      title: 'Gol nos próximos 5 minutos?',
      category: 'futebol',
      options: [
        { id: 'sim', label: 'Sim', pool: 350, betCount: 22 },
        { id: 'nao', label: 'Não', pool: 280, betCount: 18 },
      ],
      duration: 300, totalPool: 630, totalBets: 40,
      status: 'open', createdBy: admin._id,
    },
    {
      title: 'Bitcoin sobe nos próximos 3 min?',
      category: 'bitcoin',
      options: [
        { id: 'sobe', label: 'Sobe 📈', pool: 500, betCount: 30 },
        { id: 'cai', label: 'Cai 📉', pool: 420, betCount: 25 },
      ],
      duration: 180, totalPool: 920, totalBets: 55,
      status: 'open', createdBy: admin._id,
    },
  ];

  for (const pred of predictions) {
    await Prediction.create({
      ...pred,
      closesAt: new Date(Date.now() + pred.duration * 1000),
    });
  }
  console.log(`Created ${predictions.length} sample predictions`);

  console.log('\n✅ Seed completo!');
  console.log('Admin:', process.env.ADMIN_EMAIL || 'admin@predictflow.com');
  console.log('Senha:', process.env.ADMIN_PASSWORD || 'Admin@123456');
  console.log('Usuários de teste: joao@test.com / maria@test.com / ... (senha: Test@123456)');

  await mongoose.disconnect();
  process.exit(0);
};

seed().catch(err => {
  console.error('Seed error:', err);
  process.exit(1);
});
