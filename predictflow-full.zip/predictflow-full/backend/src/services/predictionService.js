const mongoose = require('mongoose');
const Prediction = require('../models/Prediction');
const Bet = require('../models/Bet');
const User = require('../models/User');
const walletService = require('./walletService');
const logger = require('../utils/logger');

const predictionService = {
  async getActive(category = null) {
    const filter = { status: { $in: ['open', 'locked'] } };
    if (category) filter.category = category;
    return Prediction.find(filter).sort({ createdAt: -1 }).limit(20);
  },

  async getById(id) {
    const prediction = await Prediction.findById(id);
    if (!prediction) throw { status: 404, message: 'Previsão não encontrada' };
    return prediction;
  },

  async create(adminId, data) {
    const { title, category, options, duration, videoUrl } = data;
    const closesAt = new Date(Date.now() + duration * 1000);

    const prediction = await Prediction.create({
      title, category, duration, videoUrl,
      options: options.map(opt => ({
        id: opt.id || opt.label.toLowerCase().replace(/\s+/g, '_'),
        label: opt.label,
        pool: 0,
        betCount: 0,
      })),
      closesAt,
      createdBy: adminId,
    });

    logger.info(`Prediction created: ${prediction._id} by admin ${adminId}`);
    return prediction;
  },

  async placeBet(userId, predictionId, optionId, amount) {
    const session = await mongoose.startSession();
    session.startTransaction();

    try {
      // Validate prediction
      const prediction = await Prediction.findById(predictionId).session(session);
      if (!prediction) throw { status: 404, message: 'Previsão não encontrada' };
      if (prediction.status !== 'open') throw { status: 400, message: 'Previsão fechada' };

      const option = prediction.options.find(o => o.id === optionId);
      if (!option) throw { status: 400, message: 'Opção inválida' };

      if (amount < 1) throw { status: 400, message: 'Aposta mínima: R$1' };
      if (amount > 10000) throw { status: 400, message: 'Aposta máxima: R$10.000' };

      // Check existing bet
      const existingBet = await Bet.findOne({ userId, predictionId }).session(session);
      if (existingBet) throw { status: 400, message: 'Você já apostou nesta previsão' };

      // Debit user balance
      const user = await User.findById(userId).session(session);
      if (!user || user.balance < amount) throw { status: 400, message: 'Saldo insuficiente' };

      const balanceBefore = user.balance;
      user.balance = parseFloat((user.balance - amount).toFixed(2));
      user.totalWagered += amount;
      user.xp += Math.floor(amount);
      user.recalculateLevel();
      await user.save({ session });

      // Calculate odds (parimutuel)
      const newPool = prediction.totalPool + amount;
      const newOptionPool = option.pool + amount;
      const odds = (newPool * (1 - prediction.houseEdge)) / newOptionPool;
      const potentialPayout = parseFloat((amount * odds).toFixed(2));

      // Create bet
      const bet = await Bet.create([{
        userId, predictionId,
        optionId, optionLabel: option.label,
        amount, oddsAtBet: odds, potentialPayout,
        status: 'pending',
      }], { session });

      // Update prediction pools
      prediction.totalPool += amount;
      prediction.totalBets += 1;
      option.pool += amount;
      option.betCount += 1;
      prediction.markModified('options');
      await prediction.save({ session });

      // Log transaction
      const { Transaction } = require('../models/Transaction');
      // Use walletService credit inline since session is active
      await require('../models/Transaction').create([{
        userId, type: 'bet', amount,
        balanceBefore, balanceAfter: user.balance,
        description: `Aposta: ${prediction.title} → ${option.label}`,
        referenceId: bet[0]._id.toString(),
        status: 'completed',
      }], { session });

      await session.commitTransaction();
      logger.info(`Bet placed: user=${userId} prediction=${predictionId} amount=${amount}`);

      return { bet: bet[0], balance: user.balance, odds, potentialPayout };
    } catch (err) {
      await session.abortTransaction();
      throw err;
    } finally {
      session.endSession();
    }
  },

  async resolve(predictionId, winnerOptionId, adminId) {
    const session = await mongoose.startSession();
    session.startTransaction();

    try {
      const prediction = await Prediction.findById(predictionId).session(session);
      if (!prediction) throw { status: 404, message: 'Previsão não encontrada' };
      if (prediction.status === 'resolved') throw { status: 400, message: 'Já resolvida' };

      const winnerOption = prediction.options.find(o => o.id === winnerOptionId);
      if (!winnerOption) throw { status: 400, message: 'Opção vencedora inválida' };

      prediction.status = 'resolved';
      prediction.winnerOptionId = winnerOptionId;
      prediction.resolvedBy = adminId;
      prediction.resolvedAt = new Date();
      await prediction.save({ session });

      // Distribute payouts to winners
      const winnerBets = await Bet.find({
        predictionId, optionId: winnerOptionId, status: 'pending'
      }).session(session);

      const loserBets = await Bet.find({
        predictionId, status: 'pending',
        optionId: { $ne: winnerOptionId }
      }).session(session);

      const totalPool = prediction.totalPool;
      const winnerPool = winnerOption.pool;
      const houseEdge = prediction.houseEdge;

      let totalPaid = 0;

      for (const bet of winnerBets) {
        const odds = winnerPool > 0 ? (totalPool * (1 - houseEdge)) / winnerPool : 1;
        const payout = parseFloat((bet.amount * odds).toFixed(2));

        bet.status = 'won';
        bet.actualPayout = payout;
        await bet.save({ session });

        const user = await User.findById(bet.userId).session(session);
        if (user) {
          const before = user.balance;
          user.balance = parseFloat((user.balance + payout).toFixed(2));
          user.totalWon += payout;
          user.xp += Math.floor(payout * 0.5);
          user.recalculateLevel();
          await user.save({ session });

          await require('../models/Transaction').create([{
            userId: bet.userId, type: 'payout', amount: payout,
            balanceBefore: before, balanceAfter: user.balance,
            description: `Prêmio: ${prediction.title} → ${winnerOption.label}`,
            referenceId: bet._id.toString(), status: 'completed',
          }], { session });

          totalPaid += payout;
        }
      }

      // Mark losers
      await Bet.updateMany(
        { predictionId, status: 'pending', optionId: { $ne: winnerOptionId } },
        { status: 'lost' },
        { session }
      );

      await session.commitTransaction();

      const houseRevenue = totalPool - totalPaid;
      logger.info(`Prediction resolved: ${predictionId} winner=${winnerOptionId} paid=${totalPaid} house=${houseRevenue}`);

      return {
        prediction,
        winnerOption,
        totalPool,
        totalPaid,
        houseRevenue,
        winnersCount: winnerBets.length,
        losersCount: loserBets.length,
      };
    } catch (err) {
      await session.abortTransaction();
      throw err;
    } finally {
      session.endSession();
    }
  },

  async getUserBets(userId, page = 1, limit = 20) {
    const [bets, total] = await Promise.all([
      Bet.find({ userId })
        .populate('predictionId', 'title category')
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit),
      Bet.countDocuments({ userId })
    ]);
    return { bets, total, pages: Math.ceil(total / limit), page };
  },
};

module.exports = predictionService;
