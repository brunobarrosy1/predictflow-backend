/**
 * Payment Service — Abstraction Layer
 * Pronto para integrar Mercado Pago, Stripe ou qualquer gateway
 */

const logger = require('../utils/logger');

// Interface base — implemente um desses providers
const providers = {
  mercadopago: {
    async createDeposit({ userId, amount, email }) {
      // TODO: Integrar Mercado Pago
      // const mp = new MercadoPago({ accessToken: process.env.MERCADOPAGO_ACCESS_TOKEN });
      // const payment = await mp.payment.create({ ... });
      throw new Error('Mercado Pago não configurado ainda');
    },
    async confirmDeposit(paymentId) {
      // TODO: Verificar status do pagamento
      throw new Error('Mercado Pago não configurado ainda');
    },
    async requestWithdraw({ userId, amount, pixKey }) {
      // TODO: Criar transferência PIX
      throw new Error('Mercado Pago não configurado ainda');
    },
  },

  stripe: {
    async createDeposit({ userId, amount, email }) {
      // TODO: Integrar Stripe
      // const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
      // const intent = await stripe.paymentIntents.create({ ... });
      throw new Error('Stripe não configurado ainda');
    },
    async confirmDeposit(paymentIntentId) {
      throw new Error('Stripe não configurado ainda');
    },
    async requestWithdraw({ userId, amount }) {
      throw new Error('Stripe não configurado ainda');
    },
  },

  // Mock provider para desenvolvimento/testes
  mock: {
    async createDeposit({ userId, amount }) {
      logger.info(`[MOCK] Creating deposit: user=${userId} amount=${amount}`);
      return {
        id: `mock_${Date.now()}`,
        status: 'pending',
        qrCode: 'mock_qr_code',
        pixCopyPaste: '00020126580014br.gov.bcb.pix...',
        expiresAt: new Date(Date.now() + 30 * 60000),
      };
    },
    async confirmDeposit(paymentId) {
      logger.info(`[MOCK] Confirming deposit: ${paymentId}`);
      return { status: 'approved', amount: 100 };
    },
    async requestWithdraw({ userId, amount, pixKey }) {
      logger.info(`[MOCK] Requesting withdraw: user=${userId} amount=${amount} pix=${pixKey}`);
      return { id: `withdraw_${Date.now()}`, status: 'pending' };
    },
  },
};

// Active provider based on env
const getProvider = () => {
  if (process.env.MERCADOPAGO_ACCESS_TOKEN) return providers.mercadopago;
  if (process.env.STRIPE_SECRET_KEY) return providers.stripe;
  return providers.mock; // fallback for development
};

const paymentService = {
  async createDeposit(params) {
    return getProvider().createDeposit(params);
  },
  async confirmDeposit(paymentId) {
    return getProvider().confirmDeposit(paymentId);
  },
  async requestWithdraw(params) {
    return getProvider().requestWithdraw(params);
  },
  getActiveProvider: () => {
    if (process.env.MERCADOPAGO_ACCESS_TOKEN) return 'mercadopago';
    if (process.env.STRIPE_SECRET_KEY) return 'stripe';
    return 'mock';
  },
};

module.exports = paymentService;
