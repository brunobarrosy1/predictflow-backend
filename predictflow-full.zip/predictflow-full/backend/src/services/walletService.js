const mongoose = require('mongoose');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const logger = require('../utils/logger');

const walletService = {
  // Atomic balance operation — prevents double spending
  async debit(userId, amount, type, description, referenceId) {
    const session = await mongoose.startSession();
    session.startTransaction();
    try {
      const user = await User.findById(userId).session(session);
      if (!user) throw { status: 404, message: 'Usuário não encontrado' };
      if (user.balance < amount) throw { status: 400, message: 'Saldo insuficiente' };
      if (amount <= 0) throw { status: 400, message: 'Valor inválido' };

      const balanceBefore = user.balance;
      user.balance = parseFloat((user.balance - amount).toFixed(2));
      await user.save({ session });

      const tx = await Transaction.create([{
        userId, type, amount,
        balanceBefore, balanceAfter: user.balance,
        description, referenceId, status: 'completed'
      }], { session });

      await session.commitTransaction();
      logger.info(`Debit: user=${userId} amount=${amount} type=${type}`);
      return { balance: user.balance, transaction: tx[0] };
    } catch (err) {
      await session.abortTransaction();
      throw err;
    } finally {
      session.endSession();
    }
  },

  async credit(userId, amount, type, description, referenceId) {
    const session = await mongoose.startSession();
    session.startTransaction();
    try {
      const user = await User.findById(userId).session(session);
      if (!user) throw { status: 404, message: 'Usuário não encontrado' };
      if (amount <= 0) throw { status: 400, message: 'Valor inválido' };

      const balanceBefore = user.balance;
      user.balance = parseFloat((user.balance + amount).toFixed(2));
      await user.save({ session });

      const tx = await Transaction.create([{
        userId, type, amount,
        balanceBefore, balanceAfter: user.balance,
        description, referenceId, status: 'completed'
      }], { session });

      await session.commitTransaction();
      logger.info(`Credit: user=${userId} amount=${amount} type=${type}`);
      return { balance: user.balance, transaction: tx[0] };
    } catch (err) {
      await session.abortTransaction();
      throw err;
    } finally {
      session.endSession();
    }
  },

  async deposit(userId, amount) {
    if (amount < 10) throw { status: 400, message: 'Depósito mínimo: R$10' };
    if (amount > 50000) throw { status: 400, message: 'Depósito máximo: R$50.000' };

    const result = await walletService.credit(userId, amount, 'deposit', `Depósito de R$${amount}`);
    await User.findByIdAndUpdate(userId, { $inc: { totalDeposited: amount } });
    return result;
  },

  async requestWithdrawal(userId, amount, pixKey) {
    if (amount < 20) throw { status: 400, message: 'Saque mínimo: R$20' };

    // Check pending withdrawals
    const pending = await Transaction.findOne({
      userId, type: 'withdrawal', status: 'pending'
    });
    if (pending) throw { status: 400, message: 'Você já tem um saque pendente' };

    // Debit immediately (holds the amount)
    const result = await walletService.debit(
      userId, amount, 'withdrawal',
      `Solicitação de saque R$${amount} (PIX: ${pixKey})`
    );

    // Mark as pending for admin approval
    await Transaction.findByIdAndUpdate(result.transaction._id, {
      status: 'pending',
      metadata: { pixKey }
    });

    return result;
  },

  async getTransactions(userId, page = 1, limit = 20, type = null) {
    const filter = { userId };
    if (type) filter.type = type;

    const [transactions, total] = await Promise.all([
      Transaction.find(filter)
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit),
      Transaction.countDocuments(filter)
    ]);

    return { transactions, total, pages: Math.ceil(total / limit), page };
  },

  async claimDailyBonus(userId) {
    const user = await User.findById(userId);
    const now = new Date();
    const lastBonus = user.lastDailyBonus;

    if (lastBonus) {
      const hoursSince = (now - lastBonus) / 3600000;
      if (hoursSince < 24) {
        const hoursLeft = Math.ceil(24 - hoursSince);
        throw { status: 400, message: `Bônus disponível em ${hoursLeft}h` };
      }
    }

    const bonus = parseFloat(process.env.DAILY_BONUS || 10);
    user.lastDailyBonus = now;
    user.streak = user.streak || 1;
    user.xp += 50;
    user.recalculateLevel();
    await user.save();

    return walletService.credit(userId, bonus, 'daily', `Bônus diário (streak: ${user.streak})`);
  },
};

module.exports = walletService;
