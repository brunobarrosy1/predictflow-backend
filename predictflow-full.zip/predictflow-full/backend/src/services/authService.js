const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const logger = require('../utils/logger');

const generateTokens = (userId) => {
  const accessToken = jwt.sign(
    { userId, type: 'access' },
    process.env.JWT_ACCESS_SECRET,
    { expiresIn: process.env.JWT_ACCESS_EXPIRES || '15m' }
  );
  const refreshToken = jwt.sign(
    { userId, type: 'refresh', jti: uuidv4() },
    process.env.JWT_REFRESH_SECRET,
    { expiresIn: process.env.JWT_REFRESH_EXPIRES || '7d' }
  );
  return { accessToken, refreshToken };
};

const authService = {
  async register({ email, password, name, referralCode }) {
    const existing = await User.findOne({ email });
    if (existing) throw { status: 409, message: 'Email já cadastrado' };

    const user = new User({ email, password, name });

    // Apply referral
    if (referralCode) {
      const referrer = await User.findOne({ referralCode });
      if (referrer && referrer._id.toString() !== user._id.toString()) {
        user.referredBy = referrer._id;
        referrer.referralCount += 1;
        referrer.balance += parseFloat(process.env.REFERRAL_BONUS || 50);
        referrer.xp += 200;
        await referrer.save();

        await Transaction.create({
          userId: referrer._id, type: 'referral',
          amount: parseFloat(process.env.REFERRAL_BONUS || 50),
          balanceBefore: referrer.balance - parseFloat(process.env.REFERRAL_BONUS || 50),
          balanceAfter: referrer.balance,
          description: `Bônus de indicação: ${name}`,
        });
      }
    }

    // Signup bonus
    const bonus = parseFloat(process.env.SIGNUP_BONUS || 100);
    user.balance = bonus;
    await user.save();

    await Transaction.create({
      userId: user._id, type: 'bonus',
      amount: bonus, balanceBefore: 0, balanceAfter: bonus,
      description: 'Bônus de boas-vindas',
    });

    const tokens = generateTokens(user._id);
    user.refreshTokens.push(tokens.refreshToken);
    await user.save();

    logger.info(`New user registered: ${email}`);
    return { user: user.toSafeObject(), ...tokens };
  },

  async login({ email, password }) {
    const user = await User.findOne({ email }).select('+password');
    if (!user || !(await user.comparePassword(password))) {
      throw { status: 401, message: 'Email ou senha incorretos' };
    }
    if (user.isBanned) throw { status: 403, message: `Conta banida: ${user.banReason}` };
    if (!user.isActive) throw { status: 403, message: 'Conta desativada' };

    // Streak tracking
    const today = new Date().toDateString();
    const lastLogin = user.lastLoginDate ? new Date(user.lastLoginDate).toDateString() : null;
    const yesterday = new Date(Date.now() - 86400000).toDateString();

    if (lastLogin !== today) {
      user.streak = lastLogin === yesterday ? user.streak + 1 : 1;
      user.lastLoginDate = new Date();
    }

    const tokens = generateTokens(user._id);
    user.refreshTokens = [...(user.refreshTokens || []).slice(-4), tokens.refreshToken];
    await user.save();

    logger.info(`User logged in: ${email}`);
    return { user: user.toSafeObject(), ...tokens };
  },

  async refreshToken(token) {
    let payload;
    try {
      payload = jwt.verify(token, process.env.JWT_REFRESH_SECRET);
    } catch {
      throw { status: 401, message: 'Refresh token inválido' };
    }

    const user = await User.findById(payload.userId);
    if (!user || !user.refreshTokens.includes(token)) {
      throw { status: 401, message: 'Refresh token não encontrado' };
    }

    const tokens = generateTokens(user._id);
    user.refreshTokens = user.refreshTokens.filter(t => t !== token);
    user.refreshTokens.push(tokens.refreshToken);
    await user.save();

    return tokens;
  },

  async logout(userId, refreshToken) {
    await User.findByIdAndUpdate(userId, {
      $pull: { refreshTokens: refreshToken }
    });
  },
};

module.exports = { authService, generateTokens };
