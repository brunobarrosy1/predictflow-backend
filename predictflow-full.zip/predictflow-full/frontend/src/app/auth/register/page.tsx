'use client';
import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { useAuthStore } from '@/store/authStore';

export default function RegisterPage() {
  const router = useRouter();
  const params = useSearchParams();
  const register = useAuthStore(s => s.register);
  const [form, setForm] = useState({
    name: '', email: '', password: '',
    referralCode: params.get('ref') || '',
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(''); setLoading(true);
    try {
      await register(form);
      router.push('/dashboard');
    } catch (err: any) {
      setError(err.response?.data?.error || 'Erro ao criar conta');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-950 px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-cyan-400">⚡ PredictFlow</h1>
          <p className="text-gray-400 mt-2">Crie sua conta e ganhe R$100 de bônus</p>
        </div>

        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8">
          <h2 className="text-xl font-bold mb-6">Criar conta</h2>

          {error && (
            <div className="bg-red-900/30 border border-red-500/40 text-red-400 rounded-lg p-3 mb-4 text-sm">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {[
              { key: 'name', label: 'Nome', type: 'text', placeholder: 'Seu nome' },
              { key: 'email', label: 'Email', type: 'email', placeholder: 'seu@email.com' },
              { key: 'password', label: 'Senha', type: 'password', placeholder: 'Mínimo 6 caracteres' },
              { key: 'referralCode', label: 'Código de indicação (opcional)', type: 'text', placeholder: 'XXXXXX' },
            ].map(({ key, label, type, placeholder }) => (
              <div key={key}>
                <label className="text-sm text-gray-400 block mb-1">{label}</label>
                <input
                  type={type}
                  value={(form as any)[key]}
                  onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
                  required={key !== 'referralCode'}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-cyan-500 transition"
                  placeholder={placeholder}
                />
              </div>
            ))}

            <button
              type="submit" disabled={loading}
              className="w-full bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-black font-bold py-3 rounded-lg transition mt-2"
            >
              {loading ? 'Criando conta...' : 'Criar conta grátis'}
            </button>
          </form>

          <div className="mt-4 p-3 bg-green-900/20 border border-green-500/30 rounded-lg text-sm text-green-400 text-center">
            🎁 Bônus de R$100 ao criar sua conta
          </div>

          <p className="text-center text-gray-400 text-sm mt-4">
            Já tem conta?{' '}
            <Link href="/auth/login" className="text-cyan-400 hover:underline">Entrar</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
