'use client';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuthStore } from '@/store/authStore';

export default function ProfilePage() {
  const router = useRouter();
  const { user, loading, logout } = useAuthStore();

  useEffect(() => {
    if (!loading && !user) router.push('/auth/login');
  }, [user, loading, router]);

  const handleLogout = async () => {
    await logout();
    router.push('/auth/login');
  };

  if (loading || !user) return null;

  const xpForNextLevel = (user.level * user.level) * 100;
  const xpProgress = Math.min((user.xp / xpForNextLevel) * 100, 100);

  return (
    <div className="min-h-screen bg-gray-950">
      <header className="bg-gray-900 border-b border-gray-800 px-4 py-3 flex items-center gap-4 sticky top-0 z-10">
        <Link href="/dashboard" className="text-gray-400 hover:text-white">←</Link>
        <h1 className="font-bold text-lg">👤 Perfil</h1>
      </header>

      <div className="max-w-lg mx-auto px-4 py-6 space-y-4">
        {/* Profile card */}
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6 text-center">
          <div className="w-16 h-16 bg-cyan-900/40 border border-cyan-500/40 rounded-full flex items-center justify-center text-2xl mx-auto mb-3">
            {user.name.charAt(0).toUpperCase()}
          </div>
          <h2 className="text-xl font-bold">{user.name}</h2>
          <p className="text-gray-400 text-sm">{user.email}</p>
          <div className="flex justify-center gap-4 mt-4">
            <div className="text-center">
              <p className="text-cyan-400 font-bold text-lg">Nível {user.level}</p>
              <p className="text-gray-500 text-xs">Nível</p>
            </div>
            <div className="text-center">
              <p className="text-yellow-400 font-bold text-lg">{user.streak}🔥</p>
              <p className="text-gray-500 text-xs">Streak</p>
            </div>
            <div className="text-center">
              <p className="text-green-400 font-bold text-lg">{user.xp}</p>
              <p className="text-gray-500 text-xs">XP</p>
            </div>
          </div>
          {/* XP progress */}
          <div className="mt-4">
            <div className="flex justify-between text-xs text-gray-500 mb-1">
              <span>XP</span><span>{user.xp} / {xpForNextLevel}</span>
            </div>
            <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-cyan-500 to-purple-500 rounded-full transition-all" style={{ width: `${xpProgress}%` }} />
            </div>
          </div>
        </div>

        {/* Referral */}
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <h3 className="font-bold mb-3">🔗 Código de Indicação</h3>
          <div className="flex gap-2">
            <div className="flex-1 bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 font-mono text-cyan-400 text-lg tracking-widest text-center">
              {user.referralCode}
            </div>
            <button onClick={() => navigator.clipboard.writeText(`${window.location.origin}/auth/register?ref=${user.referralCode}`)}
              className="bg-gray-700 hover:bg-gray-600 px-4 py-2 rounded-lg text-sm transition">
              Copiar
            </button>
          </div>
          <p className="text-xs text-gray-500 mt-2">Ganhe R$50 por cada amigo que se cadastrar</p>
        </div>

        {/* Actions */}
        <div className="space-y-2">
          <Link href="/wallet" className="flex items-center justify-between bg-gray-900 border border-gray-800 rounded-xl p-4 hover:border-gray-700 transition">
            <span>💳 Carteira</span><span className="text-gray-500">→</span>
          </Link>
          {user.role === 'admin' && (
            <Link href="/admin" className="flex items-center justify-between bg-gray-900 border border-purple-800/50 rounded-xl p-4 hover:border-purple-700 transition">
              <span className="text-purple-400">⚙️ Painel Admin</span><span className="text-gray-500">→</span>
            </Link>
          )}
          <button onClick={handleLogout} className="w-full flex items-center justify-between bg-gray-900 border border-red-800/30 rounded-xl p-4 hover:border-red-700/50 transition text-red-400">
            <span>⏻ Sair</span><span className="text-gray-500">→</span>
          </button>
        </div>
      </div>
    </div>
  );
}
