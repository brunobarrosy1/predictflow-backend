'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/store/authStore';
import api from '@/lib/api';
import Link from 'next/link';

interface Transaction {
  _id: string; type: string; amount: number;
  balanceBefore: number; balanceAfter: number;
  description: string; status: string; createdAt: string;
}

const TYPE_LABELS: Record<string, { label: string; color: string }> = {
  deposit: { label: 'Depósito', color: 'text-green-400' },
  withdrawal: { label: 'Saque', color: 'text-red-400' },
  bet: { label: 'Aposta', color: 'text-yellow-400' },
  payout: { label: 'Prêmio', color: 'text-green-400' },
  bonus: { label: 'Bônus', color: 'text-cyan-400' },
  refund: { label: 'Reembolso', color: 'text-blue-400' },
  daily: { label: 'Bônus Diário', color: 'text-purple-400' },
};

export default function WalletPage() {
  const router = useRouter();
  const { user, loading, updateBalance } = useAuthStore();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [depositAmount, setDepositAmount] = useState(50);
  const [pixKey, setPixKey] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState(50);
  const [tab, setTab] = useState<'deposit' | 'withdraw' | 'history'>('deposit');
  const [msg, setMsg] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!loading && !user) router.push('/auth/login');
  }, [user, loading, router]);

  useEffect(() => { fetchTransactions(); }, []);

  const fetchTransactions = async () => {
    try {
      const { data } = await api.get('/wallet/transactions?limit=30');
      setTransactions(data.transactions);
    } catch {}
  };

  const handleDeposit = async () => {
    setSubmitting(true); setMsg('');
    try {
      const { data } = await api.post('/wallet/deposit', { amount: depositAmount });
      if (data.balance) updateBalance(data.balance);
      setMsg(`✅ R$${depositAmount} depositado com sucesso!`);
      fetchTransactions();
    } catch (err: any) {
      setMsg(`❌ ${err.response?.data?.error || 'Erro ao depositar'}`);
    } finally { setSubmitting(false); }
  };

  const handleWithdraw = async () => {
    if (!pixKey.trim()) { setMsg('❌ Informe sua chave PIX'); return; }
    setSubmitting(true); setMsg('');
    try {
      await api.post('/wallet/withdraw', { amount: withdrawAmount, pixKey });
      setMsg('✅ Saque solicitado! Aprovação em até 24h.');
      fetchTransactions();
    } catch (err: any) {
      setMsg(`❌ ${err.response?.data?.error || 'Erro ao solicitar saque'}`);
    } finally { setSubmitting(false); }
  };

  const claimDaily = async () => {
    try {
      const { data } = await api.post('/wallet/daily-bonus');
      updateBalance(data.balance);
      setMsg('✅ Bônus diário coletado!');
      fetchTransactions();
    } catch (err: any) {
      setMsg(`⚠️ ${err.response?.data?.error}`);
    }
  };

  if (loading) return null;

  return (
    <div className="min-h-screen bg-gray-950">
      <header className="bg-gray-900 border-b border-gray-800 px-4 py-3 flex items-center gap-4 sticky top-0 z-10">
        <Link href="/dashboard" className="text-gray-400 hover:text-white">←</Link>
        <h1 className="font-bold text-lg">💳 Carteira</h1>
      </header>

      <div className="max-w-lg mx-auto px-4 py-6">
        {/* Balance card */}
        <div className="bg-gradient-to-br from-cyan-900/40 to-gray-900 border border-cyan-500/30 rounded-2xl p-6 mb-6 text-center">
          <p className="text-gray-400 text-sm mb-1">Saldo disponível</p>
          <p className="text-4xl font-bold text-cyan-400">R$ {user?.balance?.toFixed(2).replace('.', ',')}</p>
          <button onClick={claimDaily} className="mt-3 text-xs bg-purple-900/40 border border-purple-500/40 text-purple-400 px-3 py-1.5 rounded-lg hover:bg-purple-900/60 transition">
            🎁 Coletar Bônus Diário
          </button>
        </div>

        {/* Message */}
        {msg && (
          <div className={`mb-4 p-3 rounded-lg text-sm ${msg.startsWith('✅') ? 'bg-green-900/30 border border-green-500/40 text-green-400' : 'bg-yellow-900/30 border border-yellow-500/40 text-yellow-400'}`}>
            {msg}
          </div>
        )}

        {/* Tabs */}
        <div className="flex gap-1 bg-gray-900 border border-gray-800 rounded-xl p-1 mb-6">
          {(['deposit', 'withdraw', 'history'] as const).map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`flex-1 py-2 rounded-lg text-sm font-bold transition ${tab === t ? 'bg-cyan-500 text-black' : 'text-gray-400 hover:text-white'}`}
            >
              {t === 'deposit' ? 'Depositar' : t === 'withdraw' ? 'Sacar' : 'Histórico'}
            </button>
          ))}
        </div>

        {tab === 'deposit' && (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-2">
              {[20, 50, 100, 200, 500, 1000].map(v => (
                <button key={v} onClick={() => setDepositAmount(v)}
                  className={`py-3 rounded-xl font-bold transition ${depositAmount === v ? 'bg-cyan-500/20 border border-cyan-500 text-cyan-400' : 'bg-gray-800 border border-gray-700 text-gray-300'}`}
                >R${v}</button>
              ))}
            </div>
            <input type="number" value={depositAmount} onChange={e => setDepositAmount(+e.target.value)}
              className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-cyan-500"
              placeholder="Outro valor" min={10}
            />
            <button onClick={handleDeposit} disabled={submitting}
              className="w-full bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-black font-bold py-4 rounded-xl transition"
            >
              {submitting ? 'Processando...' : `Depositar R$${depositAmount}`}
            </button>
            <p className="text-xs text-gray-500 text-center">Depósito mínimo: R$10 • Máximo: R$50.000</p>
          </div>
        )}

        {tab === 'withdraw' && (
          <div className="space-y-4">
            <input type="number" value={withdrawAmount} onChange={e => setWithdrawAmount(+e.target.value)}
              className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-cyan-500"
              placeholder="Valor do saque" min={20}
            />
            <input type="text" value={pixKey} onChange={e => setPixKey(e.target.value)}
              className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-cyan-500"
              placeholder="Chave PIX (CPF, email, telefone)"
            />
            <button onClick={handleWithdraw} disabled={submitting}
              className="w-full bg-red-500 hover:bg-red-400 disabled:opacity-50 text-white font-bold py-4 rounded-xl transition"
            >
              {submitting ? 'Solicitando...' : `Sacar R$${withdrawAmount}`}
            </button>
            <p className="text-xs text-gray-500 text-center">Saque mínimo: R$20 • Aprovação em até 24h</p>
          </div>
        )}

        {tab === 'history' && (
          <div className="space-y-2">
            {transactions.length === 0 && <p className="text-gray-500 text-center py-8">Nenhuma transação ainda</p>}
            {transactions.map(tx => (
              <div key={tx._id} className="bg-gray-900 border border-gray-800 rounded-xl p-4 flex items-center justify-between">
                <div>
                  <p className={`text-sm font-bold ${TYPE_LABELS[tx.type]?.color}`}>{TYPE_LABELS[tx.type]?.label}</p>
                  <p className="text-xs text-gray-500">{tx.description}</p>
                  <p className="text-xs text-gray-600">{new Date(tx.createdAt).toLocaleDateString('pt-BR')}</p>
                </div>
                <div className="text-right">
                  <p className={`font-mono font-bold ${tx.amount > 0 && tx.type !== 'bet' && tx.type !== 'withdrawal' ? 'text-green-400' : 'text-red-400'}`}>
                    {tx.type === 'bet' || tx.type === 'withdrawal' ? '-' : '+'}R${tx.amount.toFixed(2)}
                  </p>
                  <p className="text-xs text-gray-500">Saldo: R${tx.balanceAfter.toFixed(2)}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
