'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/store/authStore';
import api from '@/lib/api';
import Link from 'next/link';

interface Prediction {
  _id: string; title: string; category: string;
  options: { id: string; label: string; pool: number; betCount: number }[];
  totalPool: number; totalBets: number; status: string; duration: number;
}

const CATEGORY_LABELS: Record<string, string> = {
  transito: '🚗 Trânsito', pedestre: '🚶 Pedestre',
  animais: '🐾 Animais', futebol: '⚽ Futebol', bitcoin: '₿ Bitcoin',
};

export default function DashboardPage() {
  const router = useRouter();
  const { user, loading, updateBalance } = useAuthStore();
  const [predictions, setPredictions] = useState<Prediction[]>([]);
  const [activeCategory, setActiveCategory] = useState('transito');
  const [selectedBet, setSelectedBet] = useState<{ predId: string; optId: string; amount: number } | null>(null);
  const [betLoading, setBetLoading] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (!loading && !user) router.push('/auth/login');
  }, [user, loading, router]);

  useEffect(() => {
    fetchPredictions();
    const interval = setInterval(fetchPredictions, 5000);
    return () => clearInterval(interval);
  }, [activeCategory]);

  const fetchPredictions = async () => {
    try {
      const { data } = await api.get(`/predictions?category=${activeCategory}`);
      setPredictions(data.predictions);
    } catch {}
  };

  const placeBet = async () => {
    if (!selectedBet) return;
    setBetLoading(true); setMessage('');
    try {
      const { data } = await api.post(`/predictions/${selectedBet.predId}/bet`, {
        optionId: selectedBet.optId,
        amount: selectedBet.amount,
      });
      updateBalance(data.balance);
      setMessage(`✅ Aposta realizada! Retorno potencial: R$${data.potentialPayout.toFixed(2)}`);
      setSelectedBet(null);
      fetchPredictions();
    } catch (err: any) {
      setMessage(`❌ ${err.response?.data?.error || 'Erro ao apostar'}`);
    } finally {
      setBetLoading(false);
    }
  };

  if (loading) return <div className="min-h-screen bg-gray-950 flex items-center justify-center text-gray-400">Carregando...</div>;

  return (
    <div className="min-h-screen bg-gray-950">
      {/* Header */}
      <header className="bg-gray-900 border-b border-gray-800 px-4 py-3 flex items-center justify-between sticky top-0 z-10">
        <span className="text-cyan-400 font-bold text-lg">⚡ PredictFlow</span>
        <div className="flex items-center gap-3">
          <span className="text-cyan-400 font-mono font-bold text-sm bg-cyan-900/30 border border-cyan-500/30 px-3 py-1 rounded-lg">
            💰 R$ {user?.balance?.toFixed(2).replace('.', ',')}
          </span>
          <Link href="/wallet" className="text-xs bg-cyan-500 text-black px-3 py-2 rounded-lg font-bold hover:bg-cyan-400 transition">+ Depositar</Link>
          <Link href="/profile" className="text-gray-400 text-sm hover:text-white">👤</Link>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-4 py-6">
        {/* Category tabs */}
        <div className="flex gap-2 overflow-x-auto pb-2 mb-6 scrollbar-none">
          {Object.entries(CATEGORY_LABELS).map(([key, label]) => (
            <button key={key} onClick={() => setActiveCategory(key)}
              className={`flex-shrink-0 px-4 py-2 rounded-lg text-sm font-bold transition ${
                activeCategory === key
                  ? 'bg-cyan-500/20 border border-cyan-500 text-cyan-400'
                  : 'bg-gray-800 border border-gray-700 text-gray-400 hover:text-white'
              }`}
            >{label}</button>
          ))}
        </div>

        {/* Message */}
        {message && (
          <div className={`mb-4 p-3 rounded-lg text-sm ${message.startsWith('✅') ? 'bg-green-900/30 border border-green-500/40 text-green-400' : 'bg-red-900/30 border border-red-500/40 text-red-400'}`}>
            {message}
          </div>
        )}

        {/* Predictions */}
        <div className="space-y-4">
          {predictions.length === 0 && (
            <div className="text-center text-gray-500 py-12">Nenhuma previsão ativa nesta categoria</div>
          )}
          {predictions.map(pred => (
            <div key={pred._id} className="bg-gray-900 border border-gray-800 rounded-xl p-5">
              <div className="flex items-start justify-between mb-4">
                <h3 className="font-bold text-white">{pred.title}</h3>
                <span className="text-xs bg-green-900/30 border border-green-500/30 text-green-400 px-2 py-1 rounded font-mono">ABERTO</span>
              </div>

              {/* Options */}
              <div className="space-y-2 mb-4">
                {pred.options.map(opt => {
                  const pct = pred.totalPool > 0 ? Math.round((opt.pool / pred.totalPool) * 100) : Math.round(100 / pred.options.length);
                  const isSelected = selectedBet?.predId === pred._id && selectedBet?.optId === opt.id;
                  return (
                    <button key={opt.id} onClick={() => setSelectedBet(s => s?.predId === pred._id && s.optId === opt.id ? null : { predId: pred._id, optId: opt.id, amount: s?.predId === pred._id ? (s.amount || 10) : 10 })}
                      className={`w-full flex items-center justify-between p-3 rounded-lg border transition relative overflow-hidden ${isSelected ? 'border-cyan-500 bg-cyan-900/20' : 'border-gray-700 bg-gray-800 hover:border-gray-600'}`}
                    >
                      <div className="absolute left-0 top-0 bottom-0 bg-cyan-500/10 transition-all" style={{ width: `${pct}%` }} />
                      <span className="relative font-semibold text-sm">{opt.label}</span>
                      <div className="relative text-right">
                        <div className="text-cyan-400 font-mono font-bold text-sm">{pct}%</div>
                        <div className="text-gray-500 text-xs">R${opt.pool.toFixed(0)}</div>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Bet controls - show if option selected for this prediction */}
              {selectedBet?.predId === pred._id && (
                <div className="border-t border-gray-800 pt-4">
                  <div className="flex gap-2 mb-3">
                    {[5, 10, 20, 50].map(v => (
                      <button key={v} onClick={() => setSelectedBet(s => s ? { ...s, amount: v } : null)}
                        className={`flex-1 py-2 rounded-lg text-sm font-bold transition ${selectedBet.amount === v ? 'bg-cyan-500/20 border border-cyan-500 text-cyan-400' : 'bg-gray-800 border border-gray-700 text-gray-400'}`}
                      >R${v}</button>
                    ))}
                  </div>
                  <button onClick={placeBet} disabled={betLoading}
                    className="w-full bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-black font-bold py-3 rounded-lg transition text-sm"
                  >
                    {betLoading ? 'Processando...' : `Apostar R$${selectedBet.amount}`}
                  </button>
                </div>
              )}

              <div className="flex justify-between text-xs text-gray-500 mt-3">
                <span>👥 {pred.totalBets} apostando</span>
                <span>R$ {pred.totalPool.toFixed(2)} no pool</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
