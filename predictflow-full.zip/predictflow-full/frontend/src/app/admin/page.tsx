'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuthStore } from '@/store/authStore';
import api from '@/lib/api';

export default function AdminPage() {
  const router = useRouter();
  const { user, loading } = useAuthStore();
  const [tab, setTab] = useState<'dashboard' | 'predictions' | 'users' | 'withdrawals'>('dashboard');
  const [stats, setStats] = useState<any>(null);
  const [predictions, setPredictions] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [newPred, setNewPred] = useState({ title: '', category: 'transito', duration: 60, options: [{ label: '' }, { label: '' }] });
  const [msg, setMsg] = useState('');

  useEffect(() => {
    if (!loading && (!user || user.role !== 'admin')) router.push('/dashboard');
  }, [user, loading, router]);

  useEffect(() => {
    if (tab === 'dashboard') fetchStats();
    if (tab === 'predictions') fetchPredictions();
    if (tab === 'users') fetchUsers();
    if (tab === 'withdrawals') fetchWithdrawals();
  }, [tab]);

  const fetchStats = async () => { const { data } = await api.get('/admin/dashboard'); setStats(data); };
  const fetchPredictions = async () => { const { data } = await api.get('/admin/predictions'); setPredictions(data.predictions); };
  const fetchUsers = async () => { const { data } = await api.get('/admin/users?limit=50'); setUsers(data.users); };
  const fetchWithdrawals = async () => { const { data } = await api.get('/admin/withdrawals'); setWithdrawals(data.withdrawals); };

  const createPrediction = async () => {
    try {
      const opts = newPred.options.filter(o => o.label.trim());
      await api.post('/admin/predictions', { ...newPred, options: opts });
      setMsg('✅ Previsão criada!');
      fetchPredictions();
      setNewPred({ title: '', category: 'transito', duration: 60, options: [{ label: '' }, { label: '' }] });
    } catch (err: any) { setMsg(`❌ ${err.response?.data?.error}`); }
  };

  const resolvePrediction = async (predId: string, optionId: string) => {
    try {
      const { data } = await api.post(`/admin/predictions/${predId}/resolve`, { winnerOptionId: optionId });
      setMsg(`✅ Resolvido! Pago: R$${data.totalPaid?.toFixed(2)}`);
      fetchPredictions();
    } catch (err: any) { setMsg(`❌ ${err.response?.data?.error}`); }
  };

  const approveWithdrawal = async (id: string) => {
    await api.post(`/admin/withdrawals/${id}/approve`);
    setMsg('✅ Saque aprovado'); fetchWithdrawals();
  };
  const rejectWithdrawal = async (id: string) => {
    await api.post(`/admin/withdrawals/${id}/reject`);
    setMsg('⚠️ Saque rejeitado e valor estornado'); fetchWithdrawals();
  };

  if (loading || !user) return null;

  return (
    <div className="min-h-screen bg-gray-950">
      <header className="bg-gray-900 border-b border-purple-800/40 px-4 py-3 flex items-center gap-4 sticky top-0 z-10">
        <Link href="/dashboard" className="text-gray-400 hover:text-white">←</Link>
        <h1 className="font-bold text-lg text-purple-400">⚙️ Admin</h1>
      </header>

      <div className="max-w-4xl mx-auto px-4 py-6">
        {msg && <div className="mb-4 p-3 rounded-lg text-sm bg-gray-800 text-gray-200">{msg}</div>}

        {/* Tabs */}
        <div className="flex gap-1 bg-gray-900 border border-gray-800 rounded-xl p-1 mb-6 overflow-x-auto">
          {(['dashboard','predictions','users','withdrawals'] as const).map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`flex-shrink-0 px-4 py-2 rounded-lg text-sm font-bold transition capitalize ${tab === t ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'}`}
            >{t === 'predictions' ? 'Previsões' : t === 'users' ? 'Usuários' : t === 'withdrawals' ? 'Saques' : 'Dashboard'}</button>
          ))}
        </div>

        {/* Dashboard */}
        {tab === 'dashboard' && stats && (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {[
              { label: 'Total Usuários', value: stats.users?.total },
              { label: 'Ativos Hoje', value: stats.users?.activeToday },
              { label: 'Total Apostas', value: stats.bets?.total },
              { label: 'Volume Total', value: `R$${stats.volume?.total?.toFixed(2)}` },
              { label: 'Saques Pendentes', value: stats.pendingWithdrawals },
              { label: 'Previsões Abertas', value: stats.openPredictions },
            ].map(({ label, value }) => (
              <div key={label} className="bg-gray-900 border border-gray-800 rounded-xl p-4">
                <p className="text-gray-400 text-xs mb-1">{label}</p>
                <p className="text-2xl font-bold text-white">{value ?? '—'}</p>
              </div>
            ))}
          </div>
        )}

        {/* Predictions */}
        {tab === 'predictions' && (
          <div className="space-y-6">
            {/* Create */}
            <div className="bg-gray-900 border border-gray-800 rounded-xl p-5">
              <h3 className="font-bold mb-4">+ Nova Previsão</h3>
              <div className="space-y-3">
                <input value={newPred.title} onChange={e => setNewPred(p => ({ ...p, title: e.target.value }))}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white"
                  placeholder="Pergunta da previsão" />
                <div className="flex gap-2">
                  <select value={newPred.category} onChange={e => setNewPred(p => ({ ...p, category: e.target.value }))}
                    className="flex-1 bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white">
                    {['transito','pedestre','animais','futebol','bitcoin','custom'].map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                  <input type="number" value={newPred.duration} onChange={e => setNewPred(p => ({ ...p, duration: +e.target.value }))}
                    className="w-24 bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white"
                    placeholder="Duração (s)" />
                </div>
                {newPred.options.map((opt, i) => (
                  <input key={i} value={opt.label}
                    onChange={e => setNewPred(p => ({ ...p, options: p.options.map((o, j) => j === i ? { label: e.target.value } : o) }))}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white"
                    placeholder={`Opção ${i + 1}`} />
                ))}
                <div className="flex gap-2">
                  <button onClick={() => setNewPred(p => ({ ...p, options: [...p.options, { label: '' }] }))}
                    className="text-xs text-gray-400 hover:text-white border border-gray-700 px-3 py-1 rounded">+ Opção</button>
                  <button onClick={createPrediction}
                    className="flex-1 bg-purple-600 hover:bg-purple-500 text-white font-bold py-2 rounded-lg text-sm transition">
                    Criar Previsão
                  </button>
                </div>
              </div>
            </div>

            {/* List */}
            {predictions.map(pred => (
              <div key={pred._id} className="bg-gray-900 border border-gray-800 rounded-xl p-4">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <p className="font-bold">{pred.title}</p>
                    <p className="text-xs text-gray-500">{pred.category} • {pred.totalBets} apostas • R${pred.totalPool?.toFixed(2)}</p>
                  </div>
                  <span className={`text-xs px-2 py-1 rounded font-mono ${pred.status === 'open' ? 'bg-green-900/30 text-green-400' : pred.status === 'resolved' ? 'bg-blue-900/30 text-blue-400' : 'bg-gray-800 text-gray-400'}`}>
                    {pred.status}
                  </span>
                </div>
                {pred.status === 'open' && (
                  <div className="space-y-1">
                    {pred.options?.map((opt: any) => (
                      <button key={opt.id} onClick={() => resolvePrediction(pred._id, opt.id)}
                        className="w-full text-left bg-gray-800 hover:bg-green-900/30 border border-gray-700 hover:border-green-500/40 rounded-lg px-3 py-2 text-sm transition">
                        ✓ {opt.label} <span className="text-gray-500 text-xs">(R${opt.pool?.toFixed(0)} · {opt.betCount} apostas)</span>
                      </button>
                    ))}
                  </div>
                )}
                {pred.status === 'resolved' && (
                  <p className="text-green-400 text-sm">✓ Vencedor: {pred.options?.find((o: any) => o.id === pred.winnerOptionId)?.label}</p>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Users */}
        {tab === 'users' && (
          <div className="space-y-2">
            {users.map(u => (
              <div key={u._id} className="bg-gray-900 border border-gray-800 rounded-xl p-4 flex items-center justify-between">
                <div>
                  <p className="font-bold text-sm">{u.name}</p>
                  <p className="text-xs text-gray-500">{u.email}</p>
                  <p className="text-xs text-cyan-400">R${u.balance?.toFixed(2)}</p>
                </div>
                <div className="flex gap-2">
                  {u.isBanned ? (
                    <button onClick={async () => { await api.patch(`/admin/users/${u._id}/unban`); fetchUsers(); }}
                      className="text-xs bg-green-900/30 text-green-400 border border-green-500/40 px-2 py-1 rounded">Desbanir</button>
                  ) : (
                    <button onClick={async () => { const r = prompt('Motivo do banimento:'); if (r) { await api.patch(`/admin/users/${u._id}/ban`, { reason: r }); fetchUsers(); } }}
                      className="text-xs bg-red-900/30 text-red-400 border border-red-500/40 px-2 py-1 rounded">Banir</button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Withdrawals */}
        {tab === 'withdrawals' && (
          <div className="space-y-2">
            {withdrawals.length === 0 && <p className="text-gray-500 text-center py-8">Nenhum saque pendente</p>}
            {withdrawals.map(tx => (
              <div key={tx._id} className="bg-gray-900 border border-yellow-800/40 rounded-xl p-4">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <p className="font-bold">R${tx.amount?.toFixed(2)}</p>
                    <p className="text-xs text-gray-400">{tx.userId?.name} — {tx.userId?.email}</p>
                    <p className="text-xs text-gray-500">PIX: {tx.metadata?.pixKey}</p>
                    <p className="text-xs text-gray-600">{new Date(tx.createdAt).toLocaleString('pt-BR')}</p>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => approveWithdrawal(tx._id)}
                      className="bg-green-600 hover:bg-green-500 text-white text-xs px-3 py-1.5 rounded font-bold transition">Aprovar</button>
                    <button onClick={() => rejectWithdrawal(tx._id)}
                      className="bg-red-600 hover:bg-red-500 text-white text-xs px-3 py-1.5 rounded font-bold transition">Rejeitar</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
